// ETF레이더 — 전 종목 목록 프록시 (네이버 EUC-KR → UTF-8 변환 포함)
exports.handler = async () => {
  const url = 'https://finance.naver.com/api/sise/etfItemList.nhn'
            + '?etfType=0&targetColumn=market_sum&sortOrder=desc';
  try {
    const r = await fetch(url, { headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36',
      'Referer': 'https://finance.naver.com/sise/etf.naver',
      'Accept': 'application/json, text/plain, */*'
    }});
    const buf = await r.arrayBuffer();
    const count = (s) => (s.match(/\uFFFD/g) || []).length;
    let body;
    try {
      const u = new TextDecoder('utf-8').decode(buf);
      if (count(u) === 0) body = u;
      else {
        const k = new TextDecoder('euc-kr').decode(buf);
        body = count(k) < count(u) ? k : u;
      }
    } catch (e) { body = new TextDecoder('euc-kr').decode(buf); }
    return { statusCode: r.status, headers: {
      'content-type': 'application/json; charset=utf-8',
      'access-control-allow-origin': '*',
      'cache-control': 'public, max-age=300'
    }, body };
  } catch (e) {
    return { statusCode: 502, headers: {'access-control-allow-origin':'*'},
      body: JSON.stringify({ error: String(e) }) };
  }
};
