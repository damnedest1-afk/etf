// ETF레이더 — KRX 정보데이터시스템 프록시
// ?type=list       : ETF 전종목 시세 (MDCSTAT04301)
// ?type=ret&days=N : 전종목 기간 등락률 (bld 후보 자동 탐색)
const KRX_URL='https://data.krx.co.kr/comm/bldAttendant/getJsonData.cmd';
const HEADERS={
  'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36',
  'Referer':'https://data.krx.co.kr/contents/MDC/MDI/mdiLoader/index.cmd?menuId=MDC0201',
  'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
  'Accept':'application/json'
};
const fmt=d=>d.toISOString().slice(0,10).replace(/-/g,'');
const cors={'content-type':'application/json; charset=utf-8','access-control-allow-origin':'*','cache-control':'public, max-age=600'};
async function call(params){
  const r=await fetch(KRX_URL,{method:'POST',headers:HEADERS,body:new URLSearchParams(params).toString()});
  return await r.text();
}
function rows(t){try{const j=JSON.parse(t);return j.output||j.OutBlock_1||[]}catch(e){return[]}}
exports.handler=async(event)=>{
  const p=(event&&event.queryStringParameters)||{};
  try{
    if(p.type==='ret'){
      const days=Math.max(5,Math.min(400,+p.days||30));
      const strtDd=fmt(new Date(Date.now()-days*864e5)),endDd=fmt(new Date());
      /* ETF 전종목 등락률 bld 후보를 순서대로 시도 */
      const blds=['dbms/MDC/STAT/standard/MDCSTAT04401','dbms/MDC/STAT/standard/MDCSTAT04701','dbms/MDC/STAT/standard/MDCSTAT04501'];
      for(const bld of blds){
        const t=await call({bld,locale:'ko_KR',strtDd,endDd,share:'1',money:'1',csvxls_isNo:'false'});
        const rs=rows(t);
        if(rs.length>50&&rs[0]&&(rs[0].FLUC_RT!=null)&&(rs[0].ISU_SRT_CD!=null||rs[0].ISU_CD!=null))
          return{statusCode:200,headers:cors,body:t};
      }
      return{statusCode:502,headers:cors,body:JSON.stringify({error:'krx ret empty(all blds)'})};
    }
    for(let i=0;i<8;i++){
      const t=await call({bld:'dbms/MDC/STAT/standard/MDCSTAT04301',locale:'ko_KR',
        trdDd:fmt(new Date(Date.now()-i*864e5)),share:'1',money:'1',csvxls_isNo:'false'});
      if(rows(t).length>50)return{statusCode:200,headers:cors,body:t};
    }
    return{statusCode:502,headers:cors,body:JSON.stringify({error:'krx list empty'})};
  }catch(e){
    return{statusCode:502,headers:cors,body:JSON.stringify({error:String(e)})};
  }
};
